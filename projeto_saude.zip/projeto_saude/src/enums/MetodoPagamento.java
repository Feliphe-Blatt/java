package enums;

public enum MetodoPagamento {
    DINHEIRO, CARTAO, PIX;
}
