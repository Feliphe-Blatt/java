package enums;

public enum TipoDeServico {
  ESTETICA, ESPORTE, NUTRICAO, SAUDE, OUTROS;
}
