package model;

public class Servicos {
}
