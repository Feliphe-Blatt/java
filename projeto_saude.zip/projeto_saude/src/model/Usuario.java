// src/model/Usuario.java
package model;

public interface Usuario {
  int getId();
  String getNome();
  String getEmail();
  String getContato();
  String getSenha();
}